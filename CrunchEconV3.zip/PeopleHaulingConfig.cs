﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using CrunchEconV3;
using CrunchEconV3.Handlers;
using CrunchEconV3.Interfaces;
using CrunchEconV3.Models;
using CrunchEconV3.Models.Contracts;
using CrunchEconV3.Utils;
using Sandbox.Game.Entities.Blocks;
using Sandbox.Game.World;
using VRage.Utils;
using VRageMath;

namespace CrunchEconContractModels.Config
{
    public class PeopleHaulingContractConfig : IContractConfig
    {       //check the discord for documentation on what each thing in the interface does 
        //https://discord.gg/cQFJeKvVAA
        public void Setup()
        {
            DeliveryGPSes = new List<string>() { "Put a gps here" };
            PassengerBlocksAvailable = new List<PassengerBlock>()
            {
                new PassengerBlock()
                {
                    BlockPairName = "Bed",
                    PassengerSpace = 2
                }
            };
        }

        public ICrunchContract GenerateFromConfig(MyContractBlock __instance, MyStation keenstation, long idUsedForDictionary)
        {
            if (this.ChanceToAppear < 1)
            {
                var random = CrunchEconV3.Core.random.NextDouble();
                if (random > this.ChanceToAppear)
                {
                    return null;
                }
            }
            var contract = new CrunchPeopleHaulingContractImplementation();
            contract.RewardMoney = Core.random.Next((int)this.PricePerPassengerMin,
                (int)this.PricePerPassengerMax);

            var description = new StringBuilder();
            contract.ContractType = "CrunchPeopleTransport";
            contract.BlockId = idUsedForDictionary;
            contract.CanAutoComplete = false;
            contract.PassengerBlocks = this.PassengerBlocksAvailable;
            contract.ReputationGainOnComplete = Core.random.Next(this.ReputationGainOnCompleteMin, this.ReputationGainOnCompleteMax);
            contract.ReputationLossOnAbandon = this.ReputationLossOnAbandon;
            contract.SecondsToComplete = this.SecondsToComplete;
            contract.DefinitionId = "MyObjectBuilder_ContractTypeDefinition/Deliver";
            contract.Name = $"People Transport Contract";
            contract.ReputationRequired = this.ReputationRequired;
            contract.CanAutoComplete = true;
            contract.CollateralToTake = (Core.random.Next((int)this.CollateralMin, (int)this.CollateralMax));
            contract.DeliverLocation = AssignDeliveryGPS(__instance, keenstation, idUsedForDictionary);
            if (this.BonusPerKMDistance != 0)
            {
                var distance = Vector3.Distance(contract.DeliverLocation, __instance != null ? __instance.PositionComp.GetPosition() : keenstation.Position);
                var division = distance / 1000;
                var distanceBonus = (long)(division * this.BonusPerKMDistance);
                if (distanceBonus > 0)
                {
                    contract.DistanceReward += distanceBonus;
                }
            }

            description.AppendLine($"Reward = {contract.RewardMoney} multiplied by Passenger count");
            description.AppendLine($" ||| Maximum possible passengers: {1500 * this.ReputationMultiplierForMaximumPassengers}");
            foreach (var passengerBlock in this.PassengerBlocksAvailable)
            {
                description.AppendLine($"||| {passengerBlock.BlockPairName} provides {passengerBlock.PassengerSpace} capacity");
            }

            description.AppendLine($" ||| Distance bonus applied {contract.DistanceReward:##,###}");

            if (this.ReputationRequired != 0)
            {
                description.AppendLine($" ||| Reputation with owner required: {this.ReputationRequired}");
            }

            contract.Description = description.ToString();
            return contract;
        }

        public Vector3 AssignDeliveryGPS(MyContractBlock __instance, MyStation keenstation, long idUsedForDictionary)
        {
            if (keenstation != null)
            {
                for (int i = 0; i < 10; i++)
                {
                    //this will only pick stations from the same faction
                    //var found = StationHandler.KeenStations.Where(x => x.FactionId == keenstation.FactionId).ToList().GetRandomItemFromList();
                    var found = StationHandler.KeenStations.GetRandomItemFromList();
                    var foundFaction = MySession.Static.Factions.TryGetFactionById(found.FactionId);
                    if (foundFaction == null)
                    {
                        i++;
                        continue;
                    }
                    return found.Position;
                }
            }

            if (this.DeliveryGPSes.Any())
            {
                if (this.DeliveryGPSes != null && this.DeliveryGPSes.Any())
                {
                    var random = this.DeliveryGPSes.GetRandomItemFromList();
                    var GPS = GPSHelper.ScanChat(random);
                    if (GPS != null)
                    {
                        return GPS.Coords;
                    }
                }
            }
            var thisStation = StationHandler.GetStationNameForBlock(idUsedForDictionary);
            for (int i = 0; i < 10; i++)
            {

                var station = Core.StationStorage.GetAll().GetRandomItemFromList();
                if (station.FileName == thisStation)
                {
                    i++;
                    continue;
                }
                var GPS = GPSHelper.ScanChat(station.LocationGPS);
                return GPS.Coords;
            }

            return Vector3.Zero;
        }

        public int AmountOfContractsToGenerate { get; set; } = 3;
        public float ChanceToAppear { get; set; } = 0.5f;
        public long CollateralMin { get; set; } = 1;
        public long CollateralMax { get; set; } = 3;
        public List<string> DeliveryGPSes { get; set; }
        public long PricePerPassengerMin { get; set; } = 1;
        public long PricePerPassengerMax { get; set; } = 3;
        public long BonusPerKMDistance { get; set; } = 1;
        public long SecondsToComplete { get; set; } = 1200;
        public int ReputationRequired { get; set; } = 0;
        public int ReputationGainOnCompleteMin { get; set; } = 1;
        public int ReputationGainOnCompleteMax { get; set; } = 3;
        public int ReputationLossOnAbandon { get; set; } = 5;
        public double ReputationMultiplierForMaximumPassengers { get; set; } = 0.3;
        public List<PassengerBlock> PassengerBlocksAvailable { get; set; }
    }
}
